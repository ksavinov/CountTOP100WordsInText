public interface ResultPrinterInterface {
    public void printTotalAmount(Result result);

    public void printTopWords(Result result);
}
